//
//  FileDetailViewController.m
//  mbbox
//
//  Created by Muzammil Peer on 11/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "FileDetailViewController.h"
#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"
#import "WebViewController.h"
#import "AppSetting.h"

@interface FileDetailViewController ()
- (void)imageFetchComplete:(ASIHTTPRequest *)request;
- (void)imageFetchFailed:(ASIHTTPRequest *)request;
- (void)fileDownloadFetchComplete:(ASIHTTPRequest *)request;
- (void)fileDownloadFailed:(ASIHTTPRequest *)request;
@end

@implementation FileDetailViewController
@synthesize lblWidth,lblHeight,lblFileSize,lblCreatedDate,lblModifiedDate,lblFileName,previewImage;
@synthesize progressIndicator;
@synthesize selectedObject;
@synthesize docInteractionController;

- (NSString *)formattedFileSize:(unsigned long long)size
{
	NSString *formattedStr = nil;
    if (size == 0) 
		formattedStr = @"Empty";
	else 
		if (size > 0 && size < 1024) 
			formattedStr = [NSString stringWithFormat:@"%qu bytes", size];
        else 
            if (size >= 1024 && size < pow(1024, 2)) 
                formattedStr = [NSString stringWithFormat:@"%.1f KB", (size / 1024.)];
            else 
                if (size >= pow(1024, 2) && size < pow(1024, 3))
                    formattedStr = [NSString stringWithFormat:@"%.2f MB", (size / pow(1024, 2))];
                else 
                    if (size >= pow(1024, 3)) 
                        formattedStr = [NSString stringWithFormat:@"%.3f GB", (size / pow(1024, 3))];
	
	return formattedStr;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
}

- (void)setupDocumentControllerWithURL:(NSURL *)url
{
    if (self.docInteractionController == nil)
    {
        self.docInteractionController = [UIDocumentInteractionController interactionControllerWithURL:url];
        self.docInteractionController.delegate = self;
    }
    else
    {
        self.docInteractionController.URL = url;
    }
}
/////////////////

- (void)fileDownloadFetchComplete:(ASIHTTPRequest *)request
{
    downlaodURL = [[NSString alloc] initWithString:[request downloadDestinationPath]];
    //[self setupDocumentControllerWithURL:[NSURL URLWithString:downlaodURL]];
    // for case 3 we use the QuickLook APIs directly to preview the document -
    QLPreviewController *previewController = [[QLPreviewController alloc] init];
    previewController.dataSource = self;
    previewController.delegate = self;
    
    // start previewing the document at the current section index
    previewController.currentPreviewItemIndex = 0;
    [[self navigationController] pushViewController:previewController animated:YES];
    [previewController release];
    
    /*
	UIImage *img = [UIImage imageWithContentsOfFile:[request downloadDestinationPath]];
	if (img) {
		if ([previewImage image]) {
		} else {
			[previewImage setImage:img];
		}
	}
     */
}

- (void)fileDownloadFetchFailed:(ASIHTTPRequest *)request
{
	if (!failed) {
		if ([[request error] domain] != NetworkRequestErrorDomain || [[request error] code] != ASIRequestCancelledErrorType) {
			UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Download failed" message:@"Failed to download images" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alertView show];
		}
		failed = YES;
	}
}
- (void)imageFetchComplete:(ASIHTTPRequest *)request
{
	UIImage *img = [UIImage imageWithContentsOfFile:[request downloadDestinationPath]];
	if (img) {
		if ([previewImage image]) {
		} else {
			[previewImage setImage:img];
		}
	}
}

- (void)imageFetchFailed:(ASIHTTPRequest *)request
{
	if (!failed) {
		if ([[request error] domain] != NetworkRequestErrorDomain || [[request error] code] != ASIRequestCancelledErrorType) {
			UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Download failed" message:@"Failed to download images" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alertView show];
		}
		failed = YES;
	}
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        //selectedObject = [[NSMutableDictionary alloc] init];
        newMan = [[Manager alloc] init];
        newMan.Delegate = (id)self;
    }
    return self;
}
-(void) response : (NSObject *) reply ofid : (NSNumber *) responseID {
    NSMutableDictionary *responsed = (NSMutableDictionary*)reply;
    
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Response " message:[responsed objectForKey:@"Code"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert setTag:kUploadAlertView];
    [alert show];
    [alert release];
    
    
    //NSLog(@"Code %@",[responsed objectForKey:@"Code"]);
    
    //  HelloWorldLayer *node = (HelloWorldLayer*)self.parent;  
}
-(IBAction)preview:(id)sender
{/*
    NSString *fileType = [selectedObject objectForKey:@"File Type"];
    if([fileType caseInsensitiveCompare:@"png"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"jpg"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"gif"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"jpeg"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"svg"] == NSOrderedSame 
       )
    {
        [self getMyImage:[selectedObject objectForKey:@"Http"]];
    }else {
        NSString *myPath = [NSString stringWithFormat:@"http://ombbox.muzammilpeer.me/mbbox/connectors/php/filemanager.php?mode=download&path=%@&thumbnail=true",[selectedObject objectForKey:@"Path"]];
        UIApplication *ourApplication = [UIApplication sharedApplication];
        NSURL *ourURL = [NSURL URLWithString:myPath];
        [ourApplication openURL:ourURL];
    }
   */ 
    NSString *fullPath = [NSString stringWithFormat:@"http://ombbox.muzammilpeer.me/mbbox/connectors/php/filemanager.php?mode=download&path=%@&thumbnail=true",[selectedObject objectForKey:@"Path"]];
    WebViewController *web = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    web.fileURL = [NSURL URLWithString:fullPath];
    [self.navigationController pushViewController:web animated:YES];
    [web release];
}


#pragma mark -
#pragma mark UIDocumentInteractionControllerDelegate

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)interactionController
{
    return self;
}


#pragma mark -
#pragma mark QLPreviewControllerDataSource

// Returns the number of items that the preview controller should preview
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)previewController
{
    NSInteger numToPreview = 1;
 /*   
    NSIndexPath *selectedIndexPath = [self.tableView indexPathForSelectedRow];
    if (selectedIndexPath.section == 0)
        numToPreview = NUM_DOCS;
    else
        numToPreview = self.documentURLs.count;
    */
    return numToPreview;
}

- (void)previewControllerDidDismiss:(QLPreviewController *)controller
{
    // if the preview dismissed (done button touched), use this method to post-process previews
}

// returns the item that the preview controller should preview
- (id)previewController:(QLPreviewController *)previewController previewItemAtIndex:(NSInteger)idx
{
    return [NSURL URLWithString:downlaodURL];
}


-(IBAction)downloadFile:(id)sender
{
    
    NSString *myPath = [NSString stringWithFormat:@"http://ombbox.muzammilpeer.me/mbbox/connectors/php/filemanager.php?mode=download&path=%@&thumbnail=true",[selectedObject objectForKey:@"Path"]];
    NSLog(@"Download URL = %@",myPath);
    /*
    // Opens a video of an iPad 2 Commercial
    UIApplication *ourApplication = [UIApplication sharedApplication];
    NSString *ourPath = [selectedObject objectForKey:@"Path"];
    NSURL *ourURL = [NSURL URLWithString:myPath];
    [ourApplication openURL:ourURL];
     */
//    [newMan getFolder:@"/"];
    
    // [self setupDocumentControllerWithURL:ourURL];
/*     
    // for case 3 we use the QuickLook APIs directly to preview the document -
    QLPreviewController *previewController = [[QLPreviewController alloc] init];
    previewController.dataSource = self;
    previewController.delegate = self;
    
    // start previewing the document at the current section index
    previewController.currentPreviewItemIndex = 0;
    [[self navigationController] pushViewController:previewController animated:YES];
    [previewController release];
 */
    
    [previewImage setImage:nil];
	
	if (!networkQueue) {
		networkQueue = [[ASINetworkQueue alloc] init];	
	}else {
        [networkQueue release];
        networkQueue = nil;
		networkQueue = [[ASINetworkQueue alloc] init];	
    }
	failed = NO;
	[networkQueue reset];
	[networkQueue setDownloadProgressDelegate:progressIndicator];
	[networkQueue setRequestDidFinishSelector:@selector(fileDownloadFetchComplete:)];
	[networkQueue setRequestDidFailSelector:@selector(fileDownloadFetchFailed:)];
	[networkQueue setShowAccurateProgress:true];
	[networkQueue setDelegate:self];
	
	ASIHTTPRequest *request;
	request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:myPath]];
	[request setDownloadDestinationPath:[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:[selectedObject objectForKey:@"Filename"]]];
	//[request setDownloadProgressDelegate:progressIndicator];
    [request setUserInfo:[NSDictionary dictionaryWithObject:@"request1" forKey:@"name"]];
	[networkQueue addOperation:request];
    
	[networkQueue go];    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == kRenameAlertView)
    {
        if (buttonIndex == 0)
        {
            NSLog(@"Button Index Zero ");
        }
        if (buttonIndex == 1)
        {
            NSLog(@"Button Index One");
            NSString * str = txtRename.text;
            if(str != NULL && str.length > 0)
            {
                [newMan renamed:str oldPath:[selectedObject objectForKey:@"Path"]];
            }
        }
    }
}
-(IBAction)renameFile:(id)sender
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Enter New Name " message:@"         " delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"Ok", nil];
    txtRename =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
    [txtRename setBackgroundColor:[UIColor whiteColor]];
    [txtRename setTag:kRenameAlertViewText];
    [alert setTag:kRenameAlertView];
    [alert addSubview:txtRename];
    [alert show];
    [alert release];
    

}
-(IBAction)deleteFile:(id)sender
{
    [newMan deleted:[selectedObject objectForKey:@"Path"]];
}
- (void) initPopUpView {
    popup = [[FlipsideViewController alloc] initWithNibName:@"FlipsideViewController" bundle:nil];
    popup.view.backgroundColor = [UIColor clearColor];
    popup.view.alpha = 0;
    popup.view.frame = CGRectMake (160, 240, 0, 0);
    [self.navigationController.view addSubview:popup.view];
}

- (void) animatePopUpShow {
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationWillStartSelector:@selector(initPopUpView)];
    
    popup.view.alpha = 1;
    popup.view.backgroundColor = [UIColor clearColor];
    popup.view.frame = CGRectMake (0, 0, self.view.window.frame.size.width-20, self.view.window.frame.size.height-20);
    
    [UIView commitAnimations];
}
-(IBAction)editFile:(id)sender
{
    [self animatePopUpShow];
}

-(void) getMyImage:(NSString*)imagePath
{
    [previewImage setImage:nil];
	
	if (!networkQueue) {
		networkQueue = [[ASINetworkQueue alloc] init];	
	}
	failed = NO;
	[networkQueue reset];
	[networkQueue setDownloadProgressDelegate:progressIndicator];
	[networkQueue setRequestDidFinishSelector:@selector(imageFetchComplete:)];
	[networkQueue setRequestDidFailSelector:@selector(imageFetchFailed:)];
	[networkQueue setShowAccurateProgress:true];
	[networkQueue setDelegate:self];
	
	ASIHTTPRequest *request;
	request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:imagePath]];
	[request setDownloadDestinationPath:[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"1.png"]];
	//[request setDownloadProgressDelegate:imageProgressIndicator1];
    [request setUserInfo:[NSDictionary dictionaryWithObject:@"request1" forKey:@"name"]];
	[networkQueue addOperation:request];
    
	[networkQueue go];
}

-(void) generateImageURL:(NSString*)fileType httpUrl:(NSString*)httpURL
{
    /*
    if([fileType caseInsensitiveCompare:@"png"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"jpg"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"gif"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"jpeg"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"svg"] == NSOrderedSame 
       )
    {
        [self getMyImage:httpURL];
    }else {
        previewImage.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[fileType lowercaseString]]]; 
    }*/
    previewImage.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[fileType lowercaseString]]]; 
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initPopUpView];

    // Do any additional setup after loading the view from its nib.
    lblFileName.text  = [selectedObject objectForKey:@"Filename"];
    lblModifiedDate.text  = [[selectedObject objectForKey:@"Properties"] objectForKey:@"DateModified"];
    NSString* fileSize = [[selectedObject objectForKey:@"Properties"]  objectForKey:@"Size"];
    lblFileSize.text  = [self formattedFileSize:[fileSize longLongValue]];
    //[selectedObject objectForKey:@"Filename"]
    //previewImage.image  = [UIImage imageWithData:data];
    NSString *http = [selectedObject objectForKey:@"Http"];
    NSString *fileType = [selectedObject objectForKey:@"File Type"];
    [self generateImageURL:fileType httpUrl:http];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
