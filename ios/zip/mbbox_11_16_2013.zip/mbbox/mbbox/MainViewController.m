//
//  MainViewController.m
//  mbbox
//
//  Created by Muzammil Peer on 11/11/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "FileDetailViewController.h"
#import "Manager.m"
@interface MainViewController ()

@end

@implementation MainViewController

@synthesize managedObjectContext = _managedObjectContext;
@synthesize flipsidePopoverController = _flipsidePopoverController;
@synthesize myTableView = _myTableView;

@synthesize btnUp,btnAdd,btnLogin,btnLogout,btnMoveTo,btnRename;
-(void) response : (NSObject*) reply ofid : (NSNumber *) responseID {
    id responsed = nil;
    if([reply isKindOfClass:[NSMutableArray class]])
    {
        responsed = (NSMutableArray*)reply;
        [listFamilyMember  removeAllObjects];
        if(responsed != NULL)
        {
            [listFamilyMember addObjectsFromArray:responsed];
            [self.myTableView reloadData];
        }
    }else if([reply isKindOfClass:[NSMutableDictionary class]]) {
        [listFamilyMember removeObjectAtIndex:selectedIndexPath.row];
        [self.myTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:selectedIndexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    

    
   // NSLog(@"RESPONSE object %@",reply);

  //  HelloWorldLayer *node = (HelloWorldLayer*)self.parent;  
}

- (IBAction)upToParentDirectory:(id)sender
{
    if(currentDirectoryPath != NULL)
    {
        NSLog(@"Current Directoy accessed = %@",currentDirectoryPath);
        NSMutableArray *stack = [currentDirectoryPath componentsSeparatedByString:@"/"];
        if(stack.count > 1)
        [stack removeObjectAtIndex:stack.count-1];
        NSString *newPath = [stack componentsJoinedByString:@"/"];
        [currentDirectoryPath release];
        currentDirectoryPath = nil;
        
        currentDirectoryPath = [[NSString alloc] initWithString:newPath];
        [newMan getFolder:currentDirectoryPath];

        NSLog(@"New String = %@",newPath);
    }
}
- (IBAction)addFileorFolder:(id)sender
{
}
- (IBAction)renameFileorFolder:(id)sender
{
}
- (IBAction)moveTo:(id)sender
{
}
- (IBAction)logoutApp:(id)sender
{
}
- (IBAction)loginApp:(id)sender
{
}


#pragma mark - Table view data source


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return listFamilyMember.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle  reuseIdentifier:CellIdentifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
        
        UIColor *contentColor = ((indexPath.row % 2) == 0) ? [UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0]:  [UIColor colorWithRed:242.0/255 green:242.0/255 blue:242.0/255 alpha:0.0];
        UIColor *textFontColor = ((indexPath.row % 2) == 0) ? [UIColor colorWithRed:242.0/255 green:242.0/255 blue:242.0/255 alpha:1.0] :[UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0];
        
        cell.selectionStyle = ((indexPath.row % 2) == 0) ? UITableViewCellSelectionStyleGray: UITableViewCellSelectionStyleBlue;
        
        [cell.contentView setBackgroundColor:contentColor];
        cell.textLabel.textColor = textFontColor;
        cell.detailTextLabel.textColor = textFontColor;

        [cell.textLabel setBackgroundColor:[UIColor clearColor]];
        cell.detailTextLabel.font = [UIFont fontWithName:@"Helvetica" size:12];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        
        //        [cell.textLabel setBackgroundColor:color];
        
    }
    
    // Configure the cell...
    //NSLog(@"count  = %@",[[response objectAtIndex:0] objectForKey:@"Path" ]);
    
    cell.detailTextLabel.text = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Path"];
    cell.textLabel.text = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Filename"];
    bool isDir = false;
    
    NSString *filetype = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"File Type"];
    if([filetype isEqualToString:@"dir"])
    {
        isDir = true;
    }
    // if a download is deferred or in progress, return a placeholder image
    if(isDir)
    {
        cell.imageView.image = [UIImage imageNamed:@"folder_icon.png"];
    }else {
        cell.imageView.image = [UIImage imageNamed:@"doc_icon.png"];
    }
    
    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */


 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
     [newMan deleted:[[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Path"]];
     selectedIndexPath = indexPath;
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    bool isDir = false;
    NSString *filetype = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"File Type"];
    if([filetype isEqualToString:@"dir"])
    {
        isDir = true;
    }
    /*
    if([[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Parent"]!= NULL)
    {
        currentDirectoryPath = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Parent"];
    }else {
        currentDirectoryPath = [NSString stringWithFormat:@"/"];
    }*/
    [currentDirectoryPath release];
    currentDirectoryPath = nil;
    
    currentDirectoryPath = [[NSString alloc] initWithString:(NSString*)[[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Parent"]];
    NSLog(@"Current Path = %@",currentDirectoryPath);
    // if a download is deferred or in progress, return a placeholder image
    if(isDir)
    {
        NSString* selectedFolder = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Path"];
        [newMan getFolder:selectedFolder];
    }else {
        // Navigation logic may go here. Create and push another view controller.
        FileDetailViewController *detailViewController = [[FileDetailViewController alloc] initWithNibName:@"FileDetailViewController" bundle:nil];
        // ...
        // Pass the selected object to the new view controller.
        detailViewController.selectedObject = [listFamilyMember objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:detailViewController animated:YES];
        [detailViewController release];
        //[self presentModalViewController:detailViewController animated:YES];
//        [detailViewController release];
    }
    

    
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        currentDirectoryPath = [[NSString alloc] initWithString:@"/"];
        self.title = @"Home";
        newMan = [[Manager alloc] init];
        newMan.Delegate = (id)self;
        [newMan getFolder:currentDirectoryPath];
        
        listFamilyMember = [[NSMutableArray alloc] init];
        for (int i=0;i<10;i++)
        {
        //    [listFamilyMember addObject:[NSString stringWithFormat:@"test %d",i]];
        }
        _myTableView.backgroundColor = [UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0];
        
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    /*    [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [_tableViewMembers reloadData];
     */
}

- (void)viewDidUnload
{
    [self setMyTableView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}




- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

#pragma mark - Flipside View Controller
- (void)dealloc
{
    [_managedObjectContext release];
    [listFamilyMember release];
    [_myTableView release];

    [super dealloc];
}


@end
