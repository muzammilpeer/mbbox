//
//  AppSetting.h
//  mbbox
//
//  Created by Muzammil Peer on 11/14/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#ifndef mbbox_AppSetting_h
#define mbbox_AppSetting_h

#define kAppKey @"6c3p9zesriioqi8"

#define kRenameAlertView 1111
#define kDeleteAlertView 1112
#define kUploadAlertView 1113


#define kRenameAlertViewText 2221

#endif
