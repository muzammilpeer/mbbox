//
//  MainViewController.h
//  mbbox
//
//  Created by Muzammil Peer on 11/11/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <CoreData/CoreData.h>
#import "Manager.h"

@interface MainViewController : UIViewController <managerDelegate>
{
    NSMutableArray* listFamilyMember;
    Manager *newMan;
    NSString *currentDirectoryPath;
    NSIndexPath *selectedIndexPath;
}
@property (retain ,nonatomic) IBOutlet UIButton  *btnUp;
@property (retain ,nonatomic) IBOutlet UIButton  *btnAdd;
@property (retain ,nonatomic) IBOutlet UIButton  *btnRename;
@property (retain ,nonatomic) IBOutlet UIButton  *btnMoveTo;
@property (retain ,nonatomic) IBOutlet UIButton  *btnLogout;
@property (retain ,nonatomic) IBOutlet UIButton  *btnLogin;

@property (retain, nonatomic) IBOutlet UITableView *myTableView;

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

@property (strong, nonatomic) UIPopoverController *flipsidePopoverController;
- (IBAction)upToParentDirectory:(id)sender;
- (IBAction)addFileorFolder:(id)sender;
- (IBAction)renameFileorFolder:(id)sender;
- (IBAction)moveTo:(id)sender;
- (IBAction)logoutApp:(id)sender;
- (IBAction)loginApp:(id)sender;

- (IBAction)showInfo:(id)sender;

@end
