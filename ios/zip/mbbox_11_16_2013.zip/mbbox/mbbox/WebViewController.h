//
//  WebViewController.h
//  mbbox
//
//  Created by Muzammil Peer on 11/14/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController<UIWebViewDelegate>
{
    UIActivityIndicatorView *activityIndicator;
    UIWebView*webView;
}
@property (nonatomic,retain) NSURL * fileURL;
//@property (nonatomic,retain) IBOutlet UIWebView*webView;

@end
