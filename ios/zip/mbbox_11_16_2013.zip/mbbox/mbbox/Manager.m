//
//  Manager.m
//  magic_wall_initiatedSaad
//
//  Created by HuLeTS on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Manager.h"
#import "JSON.h"

@implementation Manager
@synthesize Delegate = _Delegate;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        // NSString *myurl = [NSString  stringWithFormat:@"http://192.168.0.102:8080/json.php"];

        URL = [NSString stringWithString:@"http://ombbox.muzammilpeer.me/mbbox/connectors/php/filemanager.php"];
    }
    return self;
}

- (NSString*) getQueryString :(NSDictionary*) dict
{
    NSMutableString *prams = [[NSMutableString alloc] init];
    
    for (id keys in dict) {
        [prams appendFormat:@"%@=%@&",keys,[dict objectForKey:keys]];
    }
    NSString *removeLastChar = [prams substringWithRange:NSMakeRange(0, [prams length]-1)];
    NSString *urlString = [NSString stringWithFormat:@"%@?%@",URL,removeLastChar];
    
   // NSLog(@"urlString %@",urlString); 
    return urlString;
}
- (void) getFolder:(NSString*)folder
{
    
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"getfolder",@"mode",
                          folder,@"path",
                          @"true",@"showThumbs",
                          @"271",@"time", nil];
    
    //setting u
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
/*    
    [request setPostValue:@"getfolder" forKey:@"mode"];
    //[request setPostValue:@"\/" forKey:@"path"]; 
    [request setPostValue:@"true" forKey:@"showThumbs"];
    [request setPostValue:@"571" forKey:@"time"];
 */
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
   // NSLog(@"URL string = %@",request.originalURL.description);
}
- (void) getFileInfo:(NSString*) path
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"getinfo",@"mode",
                          path,@"path",
                          @"true",@"showThumbs",
                          @"271",@"time", nil];

    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];

    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
    //NSLog(@"URL string = %@",request.originalURL.description);    
}
- (void) downloaded:(NSString*) path
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"download",@"mode",
                          path,@"path",
                          @"true",@"showThumbs",
                          @"271",@"time", nil];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
   // NSLog(@"URL string = %@",request.originalURL.description);    
    
}
- (void) previewed:(NSString*) path
{
}
- (void) deleted:(NSString*) path
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"delete",@"mode",
                          path,@"path",
                          @"271",@"time", nil];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
  //  NSLog(@"URL string = %@",request.originalURL.description);     
}
- (void) renamed:(NSString*)newname oldPath:(NSString*)oldpath
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"rename",@"mode",
                          newname,@"new",
                          oldpath,@"old",
                          @"271",@"time", nil];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
  //  NSLog(@"URL string = %@",request.originalURL.description);     
    
}
- (void) uploadfile:(NSString*)newname oldPath:(NSString*)oldpath
{
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
  //  NSLog(@"HTTP Status = %@",request.responseStatusMessage);
  //  NSLog(@"HTTP requestID = %@",request.requestID);
    // Use when fetching text data
    NSString *jsonString = [request responseString];
   // NSLog(@"response String %@",jsonString);
    id responseArray = [jsonString JSONValue];
   // NSLog(@"count  = %@",[[responseArray objectAtIndex:0] objectForKey:@"Path" ]);
    [_Delegate response:responseArray ofid:[NSNumber numberWithInt:1]]; 
}

- (void)requestFailed:(ASIHTTPRequest *)request
{

    NSError *error = [request error];
    [_Delegate response:error ofid: [NSNumber numberWithInt:11]];

    
}
-(void)dealloc
{
    [super dealloc];
}
@end
