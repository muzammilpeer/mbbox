//
//  MainViewController.h
//  mbbox
//
//  Created by Muzammil Peer on 11/11/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <CoreData/CoreData.h>
#import "Manager.h"
#import "AppDelegate.h"
#import "FileDetailViewController.h"



@interface MainViewController : UIViewController <detailViewDelegate,managerDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate>
{
    int currentRow;
    
  //  NSMutableArray* listFamilyMember;
    Manager *newMan;
    FileDetailViewController *fileDetailViewController;
    
//    NSString *currentDirectoryPath;
    NSIndexPath *selectedIndexPath;
    
    NSString *workingDirectory;
    NSMutableArray *parentDirectory;
    
    NSMutableDictionary* selectedObject;
    
    AppDelegate *appDelegate;
    
    //Pickers
    UIImagePickerController *imagePicker;
    UITextField *txtRename;
    UITextField *txtAddFile;
    

}
//for ipad
@property (nonatomic,retain) NSMutableArray *listFamilyMember;
@property (nonatomic,retain) UIPopoverController *flipsidePopoverController3;


@property (retain ,nonatomic) IBOutlet UIButton  *btnUp;
@property (retain ,nonatomic) IBOutlet UIButton  *btnAdd;
@property (retain ,nonatomic) IBOutlet UIButton  *btnRename;
@property (retain ,nonatomic) IBOutlet UIButton  *btnMoveTo;
@property (retain ,nonatomic) IBOutlet UIButton  *btnLogout;
@property (retain ,nonatomic) IBOutlet UIButton  *btnUpload;

@property (retain, nonatomic) IBOutlet UITableView *myTableView;

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

@property (strong, nonatomic) UIPopoverController *flipsidePopoverController;
- (IBAction)upToParentDirectory:(id)sender;
- (IBAction)addFileorFolder:(id)sender;
- (IBAction)renameFileorFolder:(id)sender;
- (IBAction)moveTo:(id)sender;
- (IBAction)logoutApp:(id)sender;
- (IBAction)loginApp:(id)sender;
- (IBAction)uploadFile:(id)sender;

- (IBAction)showInfo:(id)sender;

@end
