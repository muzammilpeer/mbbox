//
//  SignUpViewController.h
//  mbbox
//
//  Created by Muzammil Peer on 11/17/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Manager.h"

@interface SignUpViewController : UIViewController<UITextFieldDelegate,managerDelegate>
{
    Manager *newMan;
}
@property (retain, nonatomic) IBOutlet UITextField *txtFirstName;
@property (retain, nonatomic) IBOutlet UITextField *txtLastName;
@property (retain, nonatomic) IBOutlet UITextField *txtNickName;
@property (retain, nonatomic) IBOutlet UITextField *txtSecretKey;
@property (retain, nonatomic) IBOutlet UITextField *txtEmail;
@property (retain, nonatomic) IBOutlet UITextField *txtPassword;
@property (retain, nonatomic) IBOutlet UITextField *txtConfirmPassword;
- (IBAction)SignUp:(id)sender;
- (IBAction)Reset:(id)sender;
- (IBAction)SignIn:(id)sender;

@end
