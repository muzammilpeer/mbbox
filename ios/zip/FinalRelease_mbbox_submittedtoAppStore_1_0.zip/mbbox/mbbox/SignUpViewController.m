//
//  SignUpViewController.m
//  mbbox
//
//  Created by Muzammil Peer on 11/17/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "SignUpViewController.h"

@interface SignUpViewController ()

@end

@implementation SignUpViewController
@synthesize txtFirstName;
@synthesize txtLastName;
@synthesize txtNickName;
@synthesize txtSecretKey;
@synthesize txtEmail;
@synthesize txtPassword;
@synthesize txtConfirmPassword;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}
-(BOOL) validate
{
    if(txtSecretKey.text.length > 0 && txtPassword.text.length > 5 && txtNickName.text.length > 0 && txtLastName.text.length > 0 && txtFirstName.text.length > 0 && txtEmail.text.length > 0  && txtConfirmPassword.text.length > 5)
    {
        if(![txtConfirmPassword.text isEqualToString:txtPassword.text])
        {
            return NO;
        }
        if(![self NSStringIsValidEmail:txtEmail.text])
        {
            return NO;
        }
        return YES;
    }else {
        return NO;
    }
}
- (IBAction)SignUp:(id)sender
{
    if([self validate])
    {
        [newMan SignUp:txtEmail.text Password:txtPassword.text FirstName:txtFirstName.text LastName:txtLastName.text NickName:txtNickName.text SecretKey:txtSecretKey.text];
    }else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Please Fill all required fields with correct format(s)." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}
- (IBAction)Reset:(id)sender
{
    txtConfirmPassword.text = @"";
    txtEmail.text = @"";
    txtFirstName.text = @"";
    txtLastName.text = @"";
    txtNickName.text = @"";
    txtPassword.text = @"";
    txtSecretKey.text = @"";

    [txtConfirmPassword resignFirstResponder];
    [txtEmail resignFirstResponder];
    [txtFirstName resignFirstResponder];
    [txtLastName resignFirstResponder];
    [txtNickName resignFirstResponder];
    [txtPassword resignFirstResponder];
    [txtSecretKey resignFirstResponder];
}
- (IBAction)SignIn:(id)sender
{
    [self dismissModalViewControllerAnimated:NO];   
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIImageView *backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Wallpaper.png"]];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
   	backgroundImage.frame = CGRectMake(0,0,screenWidth,screenHeight);

    
    [self.view addSubview:backgroundImage];
    [self.view sendSubviewToBack:backgroundImage];
    [backgroundImage release];
    
    
    txtConfirmPassword.delegate = (id)self;
    txtEmail.delegate = (id)self;
    txtFirstName.delegate = (id)self;
    txtLastName.delegate = (id)self;
    txtNickName.delegate = (id)self;
    txtPassword.delegate = (id)self;
    txtSecretKey.delegate = (id)self;
    
    newMan = [[Manager alloc] init];
    newMan.Delegate = (id)self;
}

-(void) response : (NSObject*) reply ofid : (NSNumber *) responseID {
    id responsed = nil;
    NSString* respond = nil;
    if([reply isKindOfClass:[NSMutableArray class]])
    {
        responsed = (NSMutableArray*)reply;
        respond = [responsed objectAtIndex:0];
    }else if([reply isKindOfClass:[NSMutableDictionary class]]) {
        responsed = (NSMutableDictionary*)reply;
        respond = [responsed objectForKey:@"response"];
    }
    
    if([respond isEqualToString:@"1"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Sign Up Successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
        
        [self dismissModalViewControllerAnimated:NO];
    }else if([respond isEqualToString:@"-2"]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Email address already in Use!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Email address already in Use!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)viewDidUnload
{
    [self setTxtFirstName:nil];
    [self setTxtLastName:nil];
    [self setTxtNickName:nil];
    [self setTxtSecretKey:nil];
    [self setTxtEmail:nil];
    [self setTxtPassword:nil];
    [self setTxtConfirmPassword:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [txtFirstName release];
    [txtLastName release];
    [txtNickName release];
    [txtSecretKey release];
    [txtEmail release];
    [txtPassword release];
    [txtConfirmPassword release];
    [super dealloc];
}
@end
