//
//  Manager.m
//  magic_wall_initiatedSaad
//
//  Created by HuLeTS on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Manager.h"
#import "JSON.h"
#import "ASIFormDataRequest.h"

// Private stuff
@interface Manager ()
- (void)uploadFailed:(ASIHTTPRequest *)theRequest;
- (void)uploadFinished:(ASIHTTPRequest *)theRequest;
@end

@implementation Manager

@synthesize Delegate = _Delegate;
@synthesize requestd;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        // NSString *myurl = [NSString  stringWithFormat:@"http://192.168.0.102:8080/json.php"];

        URL = [NSString stringWithString:@"http://ombbox.muzammilpeer.me/connectors/php/filemanager.php"];
        LoginURL = [NSString stringWithString:@"http://ombbox.muzammilpeer.me/connectors/php/mlogin.php"];
        LogOutURL = [NSString stringWithString:@"http://ombbox.muzammilpeer.me/connectors/php/mlogout.php"];
        SignUpURL = [NSString stringWithString:@"http://ombbox.muzammilpeer.me/connectors/php/msignup.php"];
    }
    return self;
}

- (NSString*) getQueryString :(NSDictionary*) dict
{
    NSMutableString *prams = [[NSMutableString alloc] init];
    
    for (id keys in dict) {
        [prams appendFormat:@"%@=%@&",keys,[dict objectForKey:keys]];
    }
    NSString *removeLastChar = [prams substringWithRange:NSMakeRange(0, [prams length]-1)];
    NSString *urlString = [NSString stringWithFormat:@"%@?%@",URL,removeLastChar];
    
   // //NSLog(@"urlString %@",urlString);
    //[prams release];
    return urlString;
}

- (void) LogOut
{
    //setting u
    NSURL *url = [NSURL URLWithString:LogOutURL];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
    // //NSLog(@"URL string = %@",request.originalURL.description);    
}
- (void) Login:(NSString*)email Password:(NSString*)password
{
    
    //setting u
    NSURL *url = [NSURL URLWithString:LoginURL];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];
        
    [request setPostValue:email forKey:@"email"];
    [request setPostValue:password forKey:@"password"];
    
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
    // //NSLog(@"URL string = %@",request.originalURL.description);
}
- (void) SignUp:(NSString*)email Password:(NSString*)password FirstName:(NSString*)firstname LastName:(NSString*)lastname NickName:(NSString*)nickname SecretKey:(NSString*)secretkey
{

    
    //setting u
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:SignUpURL]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];
    [request setPostValue:email forKey:@"email"];
    [request setPostValue:password forKey:@"password"];
    [request setPostValue:nickname forKey:@"nickname"];
    [request setPostValue:firstname forKey:@"firstname"];
    [request setPostValue:lastname forKey:@"lastname"];
    [request setPostValue:secretkey forKey:@"secretkey"];

    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];   
}

- (void) addFolder:(NSString*) folder Path:(NSString*)path
{
    
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"addfolder",@"mode",
                          folder,@"name",
                          path,@"path",
                          @"271",@"time", nil];
    
    //setting u
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
  //  [dict release];
   // dict = nil;
}
- (void) getFolder:(NSString*)folder
{
    
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"getfolder",@"mode",
                          folder,@"path",
                          @"true",@"showThumbs",
                          @"271",@"time", nil];
    
    //setting u
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];
/*    
    [request setPostValue:@"getfolder" forKey:@"mode"];
    //[request setPostValue:@"\/" forKey:@"path"]; 
    [request setPostValue:@"true" forKey:@"showThumbs"];
    [request setPostValue:@"571" forKey:@"time"];
 */
    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
   // //NSLog(@"URL string = %@",request.originalURL.description);
   // [dict release];
   // dict = nil;
}
- (void) getFileInfo:(NSString*) path
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"getinfo",@"mode",
                          path,@"path",
                          @"true",@"showThumbs",
                          @"271",@"time", nil];

    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];

    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];

    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
    ////NSLog(@"URL string = %@",request.originalURL.description);    
}
- (void) downloaded:(NSString*) path
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"download",@"mode",
                          path,@"path",
                          @"true",@"showThumbs",
                          @"271",@"time", nil];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];

    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
   // //NSLog(@"URL string = %@",request.originalURL.description);    
    
}
- (void) previewed:(NSString*) path
{
}
- (void) deleted:(NSString*) path
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"delete",@"mode",
                          path,@"path",
                          @"271",@"time", nil];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self getQueryString:dict]]];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];

    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
   // [dict release];
   // dict = nil;
    
  //  //NSLog(@"URL string = %@",request.originalURL.description);     
}
- (void) renamed:(NSString*)newname oldPath:(NSString*)oldpath
{
    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:@"rename",@"mode",
                          newname,@"new",
                          oldpath,@"old",
                          @"271",@"time", nil];
    
    NSString* Query = [NSString stringWithFormat:@"%@",[self getQueryString:dict]];
    //NSLog(@"Query String = %@",Query);
    NSURL *url = [NSURL URLWithString:Query];
    //Making HttpRequest
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setUseCookiePersistence:YES];

    [request setDelegate:self];
    [request setTimeOutSeconds:5];
    [request startAsynchronous];
  //  [dict release];
   // dict = nil;
  //  //NSLog(@"URL string = %@",request.originalURL.description);     
    
}


- (void)uploadFinished:(ASIHTTPRequest *)theRequest
{
    //NSLog(@"%@",[NSString stringWithFormat:@"Finished uploading %llu bytes of data",[theRequest postLength]]);
    
	//[resultView setText:[NSString stringWithFormat:@"Finished uploading %llu bytes of data",[theRequest postLength]]];
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    // Clear out the old notification before scheduling a new one.
    if ([[[UIApplication sharedApplication] scheduledLocalNotifications] count] > 0)
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    // Create a new notification
    UILocalNotification *notification = [[[UILocalNotification alloc] init] autorelease];
    if (notification) {
		[notification setFireDate:[NSDate date]];
		[notification setTimeZone:[NSTimeZone defaultTimeZone]];
		[notification setRepeatInterval:0];
		[notification setSoundName:@"alarmsound.caf"];
		[notification setAlertBody:@"Boom!\r\n\r\nUpload is finished!"];
        [[UIApplication sharedApplication] scheduleLocalNotification:notification];
    }
#endif
    //NSLog(@"===================Start=====================");
    //NSLog(@"responseString %@",requestd.responseString);
    //NSLog(@"===================End======================");
    //  //NSLog(@"HTTP Status = %@",request.responseStatusMessage);
    //  //NSLog(@"HTTP requestID = %@",request.requestID);
    // Use when fetching text data
    NSString *jsonString = [requestd responseString];
    //</textarea>
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"<textarea>" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"</textarea>" withString:@""];
    id responseArray = [jsonString JSONValue];
    [_Delegate response:responseArray ofid:[NSNumber numberWithInt:1]];  
    [uploadingBar removeFromSuperview];
    [uploadingBar release];
    uploadingBar = nil;
}

- (void) uploadfile:(NSString*)filename oldPath:(NSString*)path ProgressBar:(UIView*)progressIndicator Image:(UIImage*) imageObject
{
//    progressIndicator = [[UIProgressView alloc] initWithFrame:CGRectZero];
    CGRect frame;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        frame = CGRectMake(5, 2, 310, 10);
    } else {
        frame = CGRectMake(5, 5, 768-20, 40);
    }
    
    
    uploadingBar = [[UIProgressView alloc] initWithFrame:frame];
    uploadingBar.tag = 54;
    [progressIndicator addSubview:uploadingBar];


    [requestd cancel];
	[self setRequestd:[ASIFormDataRequest requestWithURL:[NSURL URLWithString:URL]]];
	[requestd setPostValue:@"add" forKey:@"mode"];
	[requestd setPostValue:path forKey:@"currentpath"];
	[requestd setPostValue:filename forKey:@"filepath"];
	[requestd setTimeOutSeconds:20];
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
	[requestd setShouldContinueWhenAppEntersBackground:YES];
#endif
    [requestd setShowAccurateProgress:YES];
	[requestd setUploadProgressDelegate:uploadingBar];
	[requestd setDelegate:self];
	[requestd setDidFailSelector:@selector(uploadFailed:)];
	[requestd setDidFinishSelector:@selector(uploadFinished:)];
    
//	NSData *imageData1=UIImageJPEGRepresentation(imageObject, 1.0); 
	NSData *imageData1=UIImagePNGRepresentation(imageObject);
   // CGDataProviderRef provider = CGImageGetDataProvider(imageObject.CGImage);
    //NSData* data = (id)CGDataProviderCopyData(provider);
    
    [requestd setData:imageData1 withFileName:filename andContentType:@"image/png" forKey:@"newfile"]; 
 /*   
	//Create a 256KB file
	//NSData *data = [[[NSMutableData alloc] initWithLength:256*1024] autorelease];
    CGDataProviderRef provider = CGImageGetDataProvider(imageObject.CGImage);
    NSData* data = (id)CGDataProviderCopyData(provider);
//    const uint8_t* bytes = [data bytes];
    
	NSString *path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"fig1.png"];
	[data writeToFile:path atomically:NO];
	[request setFile:path forKey:@"newfile"];
/*
	//Add the file 8 times to the request, for a total request size around 2MB
	int i;
	for (i=0; i<8; i++) {
		[request setFile:path forKey:[NSString stringWithFormat:@"file-%i",i]];
	}
	*/
	[requestd startAsynchronous];
    
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    //NSLog(@"===================Start=====================");
    //NSLog(@"responseString %@",request.responseString);
    //NSLog(@"===================End======================");
  //  //NSLog(@"HTTP Status = %@",request.responseStatusMessage);
  //  //NSLog(@"HTTP requestID = %@",request.requestID);
    // Use when fetching text data
    NSString *jsonString = [request responseString];
    id responseArray = [jsonString JSONValue];
    [_Delegate response:responseArray ofid:[NSNumber numberWithInt:1]]; 
}

- (void)requestFailed:(ASIHTTPRequest *)request
{

    NSError *error = [request error];
    [_Delegate response:error ofid: [NSNumber numberWithInt:11]];

    
}
-(void)dealloc
{
    [requestd setDelegate:nil];
	[requestd setUploadProgressDelegate:nil];
	[requestd cancel];
	[requestd release];
	//[progressIndicator release];

    [super dealloc];
}
@end
