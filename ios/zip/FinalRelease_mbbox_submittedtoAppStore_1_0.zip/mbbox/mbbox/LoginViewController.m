//
//  LoginViewController.m
//  mbbox
//
//  Created by Muzammil Peer on 11/17/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "MainViewController.h"
#import "SignUpViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize txtEmail,txtPassword;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void) response : (NSObject*) reply ofid : (NSNumber *) responseID {
    id responsed = nil;
    NSString* respond = nil;
    if([reply isKindOfClass:[NSMutableArray class]])
    {
        responsed = (NSMutableArray*)reply;
        respond = [responsed objectAtIndex:0];
    }else if([reply isKindOfClass:[NSMutableDictionary class]]) {
        responsed = (NSMutableDictionary*)reply;
        respond = [responsed objectForKey:@"response"];
    }
    
    if([respond isEqualToString:@"1"])
    {
        MainViewController *viewController;
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            viewController = [[[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil] autorelease];
        } else {
            viewController = [[[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil] autorelease];
        }
        [txtEmail resignFirstResponder];
        [txtPassword resignFirstResponder];
        txtEmail.text = @"";
        txtPassword.text = @"";
        
        UINavigationController *rootNavigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
        rootNavigationController.navigationBar.tintColor = [UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0];
        [self presentModalViewController:rootNavigationController animated:NO];
        [rootNavigationController release];
        
    }else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Invalid Credentials" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

- (IBAction)login:(id)sender
{
    if(txtEmail.text != NULL && txtEmail.text.length > 0 &&  txtPassword.text != NULL && txtPassword.text.length > 0)
    {
        if([self NSStringIsValidEmail:txtEmail.text])
        {
            [newMan Login:txtEmail.text Password:txtPassword.text];
        }else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Validation" message:@"Please enter valid Email address!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
        }
    }else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Validation" message:@"Please provide your credentials." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}
- (IBAction)cancel:(id)sender
{
    txtPassword.text = @"";
    txtEmail.text = @"";
    
    [txtEmail resignFirstResponder];
    [txtPassword resignFirstResponder];
}
- (IBAction)SignUp:(id)sender
{
    SignUpViewController *viewController;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
       viewController = [[SignUpViewController alloc] initWithNibName:@"SignUpViewController" bundle:nil];
    } else {
        viewController = [[SignUpViewController alloc] initWithNibName:@"SignUpViewController_iPad" bundle:nil];
    }
    [self presentModalViewController:viewController animated:NO];
    [viewController release];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    UIImageView * backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Wallpaper.png"]];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
   	backgroundImage.frame = CGRectMake(0,0,screenWidth,screenHeight);
    
    [self.view addSubview:backgroundImage];
    [self.view sendSubviewToBack:backgroundImage];
    [backgroundImage release];
    
    newMan = [[Manager alloc] init];
    newMan.Delegate = (id)self;
    txtEmail.delegate = (id)self;
    txtPassword.delegate = (id)self;
    self.title = @"mbBox Cloud Storage";


}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
