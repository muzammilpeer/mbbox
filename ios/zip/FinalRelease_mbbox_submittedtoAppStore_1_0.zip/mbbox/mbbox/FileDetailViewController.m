//
//  FileDetailViewController.m
//  mbbox
//
//  Created by Muzammil Peer on 11/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "FileDetailViewController.h"
#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"
#import "WebViewController.h"
#import "AppSetting.h"
/*
#define IS_IPHONE ( [[[UIDevice currentDevice] model] isEqualToString:@"iPhone"])
#define IS_HEIGHT_GTE_568 [[UIScreen mainScreen ] bounds].size.height >= 568.0f
#define IS_IPHONE_5 ( IS_IPHONE && IS_HEIGHT_GTE_568 )
*/
@interface FileDetailViewController ()
- (void)imageFetchComplete:(ASIHTTPRequest *)request;
- (void)imageFetchFailed:(ASIHTTPRequest *)request;
- (void)fileDownloadFetchComplete:(ASIHTTPRequest *)request;
- (void)fileDownloadFailed:(ASIHTTPRequest *)request;
@end

@implementation FileDetailViewController
@synthesize myDelegate;
@synthesize lblWidth,lblHeight,lblFileSize,lblCreatedDate,lblModifiedDate,lblFileName,previewImage;
@synthesize progressIndicator;
@synthesize selectedObject;
@synthesize docInteractionController;




- (NSString *)formattedFileSize:(unsigned long long)size
{
	NSString *formattedStr = nil;
    if (size == 0) 
		formattedStr = @"Empty";
	else 
		if (size > 0 && size < 1024) 
			formattedStr = [NSString stringWithFormat:@"%qu bytes", size];
        else 
            if (size >= 1024 && size < pow(1024, 2)) 
                formattedStr = [NSString stringWithFormat:@"%.1f KB", (size / 1024.)];
            else 
                if (size >= pow(1024, 2) && size < pow(1024, 3))
                    formattedStr = [NSString stringWithFormat:@"%.2f MB", (size / pow(1024, 2))];
                else 
                    if (size >= pow(1024, 3)) 
                        formattedStr = [NSString stringWithFormat:@"%.3f GB", (size / pow(1024, 3))];
	
	return formattedStr;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
}

- (void)setupDocumentControllerWithURL:(NSURL *)url
{
    if (self.docInteractionController == nil)
    {
        self.docInteractionController = [UIDocumentInteractionController interactionControllerWithURL:url];
        self.docInteractionController.delegate = self;
    }
    else
    {
        self.docInteractionController.URL = url;
    }
}
/////////////////

- (void)fileDownloadFetchComplete:(ASIHTTPRequest *)request
{
    progressIndicator.hidden = YES;
    /*
    downlaodURL = [[NSString alloc] initWithString:[request downloadDestinationPath]];
    //[self setupDocumentControllerWithURL:[NSURL URLWithString:downlaodURL]];
    // for case 3 we use the QuickLook APIs directly to preview the document -
    QLPreviewController *previewController = [[QLPreviewController alloc] init];
    previewController.dataSource = self;
    previewController.delegate = self;
    
    // start previewing the document at the current section index
    previewController.currentPreviewItemIndex = 0;
    [[self navigationController] pushViewController:previewController animated:YES];
    [previewController release];
    */
    /*
	UIImage *img = [UIImage imageWithContentsOfFile:[request downloadDestinationPath]];
	if (img) {
		if ([previewImage image]) {
		} else {
			[previewImage setImage:img];
		}
	}
     */
}

- (void)fileDownloadFetchFailed:(ASIHTTPRequest *)request
{
	if (!failed) {
		if ([[request error] domain] != NetworkRequestErrorDomain || [[request error] code] != ASIRequestCancelledErrorType) {
			UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Download failed" message:@"Failed to download images" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alertView show];
		}
		failed = YES;
	}
}
- (void)imageFetchComplete:(ASIHTTPRequest *)request
{
	UIImage *img = [UIImage imageWithContentsOfFile:[request downloadDestinationPath]];
	if (img) {
		if ([previewImage image]) {
		} else {
			[previewImage setImage:img];
		}
	}
}

- (void)imageFetchFailed:(ASIHTTPRequest *)request
{
	if (!failed) {
		if ([[request error] domain] != NetworkRequestErrorDomain || [[request error] code] != ASIRequestCancelledErrorType) {
			UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Download failed" message:@"Failed to download images" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alertView show];
		}
		failed = YES;
	}
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        newMan = [[Manager alloc] init];
        newMan.Delegate = (id)self;
    }
    return self;
}
//rename {"Old Path":"\/4.png","Old Name":"4.png","New Path":"\/49.png","New Name":"49.png","Error":"","Code":"0"}
//delete {"Path":"\/49.png","Error":"","Code":"0"}
//upload <textarea>{"Path":"\/","Name":"2.jpg","Error":"","Code":0}</textarea>

-(void) response : (NSObject *) reply ofid : (NSNumber *) responseID {
    id responsed = nil;
    if([reply isKindOfClass:[NSMutableDictionary class]])
    {
        responsed = (NSMutableDictionary*)reply;
        if([responsed objectForKey:@"Old Path"] != nil && [responsed objectForKey:@"Old Name"] != nil){
            [selectedObject setObject:[responsed objectForKey:@"New Name"] forKey:@"Filename"];
            lblFileName.text = [responsed objectForKey:@"New Name"];
            self.title = [responsed objectForKey:@"New Name"];
        //    NSLog(@"New Name = %@",[responsed objectForKey:@"New Name"] );
         //   NSLog(@"Renamed Successfully Returned");
            [myDelegate loadFreshData];            
        }else if([responsed objectForKey:@"Path"] != nil && [responsed objectForKey:@"Code"] != nil){
           // NSLog(@"Deleted Successfully Returned");
            //Call Main View Delegate to get Fresh Data on delete
            [self.navigationController popViewControllerAnimated:YES];
            [myDelegate loadFreshData];
        }

        
    }
   // NSLog(@"FileDetail Response =  %@",responsed);
    /*
    
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Response " message:[responsed objectForKey:@"Code"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert setTag:kUploadAlertView];
    [alert show];
    [alert release];
    
    */
    //NSLog(@"Code %@",[responsed objectForKey:@"Code"]);
    
    //  HelloWorldLayer *node = (HelloWorldLayer*)self.parent;  
}
-(IBAction)preview:(id)sender
{
    NSString *fullPath = [NSString stringWithFormat:@"http://ombbox.muzammilpeer.me/connectors/php/filemanager.php?mode=download&path=%@&thumbnail=true",[selectedObject objectForKey:@"Path"]];
    WebViewController *viewController;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        viewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    } else {
        viewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    }
    
    viewController.fileURL = [NSURL URLWithString:fullPath];
    viewController.fileName = [selectedObject objectForKey:@"Filename"];
    [self.navigationController pushViewController:viewController animated:YES];
    [viewController release];
}


#pragma mark -
#pragma mark UIDocumentInteractionControllerDelegate

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)interactionController
{
    return self;
}


#pragma mark -
#pragma mark QLPreviewControllerDataSource

// Returns the number of items that the preview controller should preview
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)previewController
{
    NSInteger numToPreview = 1;
 /*   
    NSIndexPath *selectedIndexPath = [self.tableView indexPathForSelectedRow];
    if (selectedIndexPath.section == 0)
        numToPreview = NUM_DOCS;
    else
        numToPreview = self.documentURLs.count;
    */
    return numToPreview;
}

- (void)previewControllerDidDismiss:(QLPreviewController *)controller
{
    // if the preview dismissed (done button touched), use this method to post-process previews
}

// returns the item that the preview controller should preview
- (id)previewController:(QLPreviewController *)previewController previewItemAtIndex:(NSInteger)idx
{
    return [NSURL URLWithString:downlaodURL];
}


-(IBAction)downloadFile:(id)sender
{
    
    NSString *myPath = [NSString stringWithFormat:@"http://ombbox.muzammilpeer.me/connectors/php/filemanager.php?mode=download&path=%@&thumbnail=true",[selectedObject objectForKey:@"Path"]];
  //  NSLog(@"Download URL = %@",myPath);
	
	if (!networkQueue) {
		networkQueue = [[ASINetworkQueue alloc] init];	
	}else {
        [networkQueue release];
        networkQueue = nil;
		networkQueue = [[ASINetworkQueue alloc] init];	
    }
    progressIndicator.hidden = NO;
	failed = NO;
	[networkQueue reset];
	[networkQueue setDownloadProgressDelegate:progressIndicator];
	[networkQueue setRequestDidFinishSelector:@selector(fileDownloadFetchComplete:)];
	[networkQueue setRequestDidFailSelector:@selector(fileDownloadFetchFailed:)];
	[networkQueue setShowAccurateProgress:YES];
	[networkQueue setDelegate:self];
	
	ASIHTTPRequest *request;
	request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:myPath]];
	[request setDownloadDestinationPath:[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:[selectedObject objectForKey:@"Filename"]]];
	//[request setDownloadProgressDelegate:progressIndicator];
    [request setUserInfo:[NSDictionary dictionaryWithObject:@"request1" forKey:@"name"]];
	[networkQueue addOperation:request];
    
	[networkQueue go];    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *OldPath = [selectedObject objectForKey:@"Path"];
    if (alertView.tag == kRenameAlertView)
    {
        if (buttonIndex == 0)
        {
      //      NSLog(@"Button Index Zero ");
        }
        if (buttonIndex == 1)
        {
           // NSLog(@"Button Index One");
            NSString * str = txtRename.text;
            if(str != NULL && str.length > 0)
            {
                NSString *filetype = [selectedObject objectForKey:@"File Type"];
                
                if([filetype isEqualToString:@"dir"])
                {
                  //  NSLog(@"Folder Rename = %@ , OldPath = %@",str,OldPath);
                    [newMan renamed:str oldPath:OldPath];
                }else {
                    str = [str stringByAppendingFormat:@".%@",filetype];
                   // NSLog(@"File Rename = %@ , OldPath = %@",str,OldPath);
                    [newMan renamed:str oldPath:OldPath];
                }

            }
        }
    }else if(alertView.tag == kDeleteAlertView)
    {
        if (buttonIndex == 0)
        {
          //  NSLog(@"Button Index Zero ");
        }
        if (buttonIndex == 1)
        {
           // NSLog(@"Button Index One");
            [newMan deleted:OldPath];
        }
        
    }
}
-(IBAction)renameFile:(id)sender
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Enter New Name " message:@"         " delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"Ok", nil];
    txtRename =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
    [txtRename setBackgroundColor:[UIColor whiteColor]];
    [txtRename setTag:kRenameAlertViewText];
    [alert setTag:kRenameAlertView];
    [alert addSubview:txtRename];
    [alert show];
    [alert release];
    

}
-(IBAction)deleteFile:(id)sender
{
   // [newMan deleted:[selectedObject objectForKey:@"Path"]];
    
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Delete Confirmation!" message:@"Do you want to delete this record?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    [alert setTag:kDeleteAlertView];
    [alert show];
    [alert release];    
}
- (void) initPopUpView {
    popup = [[FlipsideViewController alloc] initWithNibName:@"FlipsideViewController" bundle:nil];
    popup.view.backgroundColor = [UIColor clearColor];
    popup.view.alpha = 0;
    popup.view.frame = CGRectMake (160, 240, 0, 0);
    [self.navigationController.view addSubview:popup.view];
}

- (void) animatePopUpShow {
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationWillStartSelector:@selector(initPopUpView)];
    
    popup.view.alpha = 1;
    popup.view.backgroundColor = [UIColor clearColor];
    popup.view.frame = CGRectMake (0, 0, self.view.window.frame.size.width-20, self.view.window.frame.size.height-20);
    
    [UIView commitAnimations];
}
-(IBAction)editFile:(id)sender
{
    [self animatePopUpShow];
}

-(void) getMyImage:(NSString*)imagePath
{
    [previewImage setImage:nil];
	
	if (!networkQueue) {
		networkQueue = [[ASINetworkQueue alloc] init];	
	}
	failed = NO;
	[networkQueue reset];
	[networkQueue setDownloadProgressDelegate:progressIndicator];
	[networkQueue setRequestDidFinishSelector:@selector(imageFetchComplete:)];
	[networkQueue setRequestDidFailSelector:@selector(imageFetchFailed:)];
	[networkQueue setShowAccurateProgress:true];
	[networkQueue setDelegate:self];
	
	ASIHTTPRequest *request;
	request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:imagePath]];
	[request setDownloadDestinationPath:[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"1.png"]];
	//[request setDownloadProgressDelegate:imageProgressIndicator1];
    [request setUserInfo:[NSDictionary dictionaryWithObject:@"request1" forKey:@"name"]];
	[networkQueue addOperation:request];
    
	[networkQueue go];
}

-(void) generateImageURL:(NSString*)fileType httpUrl:(NSString*)httpURL
{
    /*
    if([fileType caseInsensitiveCompare:@"png"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"jpg"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"gif"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"jpeg"] == NSOrderedSame ||
       [fileType caseInsensitiveCompare:@"svg"] == NSOrderedSame 
       )
    {
        [self getMyImage:httpURL];
    }else {
        previewImage.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[fileType lowercaseString]]]; 
    }*/
    previewImage.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[fileType lowercaseString]]]; 
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImageView *backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Wallpaper.png"]];
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
   	backgroundImage.frame = CGRectMake(0,0,screenWidth,screenHeight);
    
    [self.view addSubview:backgroundImage];
    [self.view sendSubviewToBack:backgroundImage];
    [backgroundImage release];
    
    [self initPopUpView];
    self.title = [selectedObject objectForKey:@"Filename"];
    // Do any additional setup after loading the view from its nib.
    lblFileName.text  = [selectedObject objectForKey:@"Filename"];
    lblModifiedDate.text  = [[selectedObject objectForKey:@"Properties"] objectForKey:@"DateModified"];
    NSString* fileSize = [[selectedObject objectForKey:@"Properties"]  objectForKey:@"Size"];
    lblFileSize.text  = [self formattedFileSize:[fileSize longLongValue]];
    //[selectedObject objectForKey:@"Filename"]
    //previewImage.image  = [UIImage imageWithData:data];
    NSString *http = [selectedObject objectForKey:@"Http"];
    NSString *fileType = [selectedObject objectForKey:@"File Type"];
    [self generateImageURL:fileType httpUrl:http];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
