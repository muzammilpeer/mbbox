//
//  FileDetailViewController.h
//  mbbox
//
//  Created by Muzammil Peer on 11/13/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Manager.h"
#import <QuickLook/QuickLook.h>
#import "FlipsideViewController.h"
@class ASINetworkQueue;

@protocol detailViewDelegate <NSObject>
-(void)loadFreshData ;
@end

@interface FileDetailViewController : UIViewController<managerDelegate,QLPreviewControllerDataSource,
QLPreviewControllerDelegate,
UIDocumentInteractionControllerDelegate,UITextFieldDelegate>
{
    ASINetworkQueue *networkQueue;
    BOOL failed;
    Manager *newMan;
    UIDocumentInteractionController *docInteractionController;
    NSString *downlaodURL;
    UITextField *txtRename;
    FlipsideViewController *popup;
    id<detailViewDelegate> myDelegate;
}
@property (nonatomic,retain) id<detailViewDelegate> myDelegate;
@property (nonatomic, retain) UIDocumentInteractionController *docInteractionController;

@property (nonatomic,retain) IBOutlet UIProgressView* progressIndicator;

@property (nonatomic,retain) NSMutableDictionary *selectedObject;
@property (nonatomic,retain) IBOutlet UILabel* lblFileSize;
@property (nonatomic,retain) IBOutlet UILabel* lblModifiedDate;
@property (nonatomic,retain) IBOutlet UILabel* lblCreatedDate;
@property (nonatomic,retain) IBOutlet UILabel* lblWidth;
@property (nonatomic,retain) IBOutlet UILabel* lblHeight;
@property (nonatomic,retain) IBOutlet UILabel* lblFileName;
@property (nonatomic,retain) IBOutlet UIImageView* previewImage;

-(IBAction)downloadFile:(id)sender;
-(IBAction)renameFile:(id)sender;
-(IBAction)deleteFile:(id)sender;
-(IBAction)editFile:(id)sender;
-(IBAction)preview:(id)sender;

@end
