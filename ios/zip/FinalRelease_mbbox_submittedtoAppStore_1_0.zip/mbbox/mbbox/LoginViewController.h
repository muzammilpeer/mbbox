//
//  LoginViewController.h
//  mbbox
//
//  Created by Muzammil Peer on 11/17/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Manager.h"

@interface LoginViewController : UIViewController<managerDelegate,UITextFieldDelegate>
{
    Manager *newMan;
}
@property (nonatomic,retain) IBOutlet UITextField* txtEmail;
@property (nonatomic,retain) IBOutlet UITextField* txtPassword;

- (IBAction)login:(id)sender;
- (IBAction)cancel:(id)sender;
- (IBAction)SignUp:(id)sender;

@end
