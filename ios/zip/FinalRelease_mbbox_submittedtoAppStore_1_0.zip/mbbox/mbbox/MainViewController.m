//
//  MainViewController.m
//  mbbox
//
//  Created by Muzammil Peer on 11/11/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "FileDetailViewController.h"
#import "Manager.m"
#import "AppSetting.h"
#import <AssetsLibrary/ALAsset.h>

@interface MainViewController ()

@end

@implementation MainViewController
@synthesize flipsidePopoverController3;
@synthesize managedObjectContext = _managedObjectContext;
@synthesize flipsidePopoverController = _flipsidePopoverController;
@synthesize myTableView = _myTableView;
@synthesize listFamilyMember;

@synthesize btnUp,btnAdd,btnUpload,btnLogout,btnMoveTo,btnRename;
-(void) response : (NSObject*) reply ofid : (NSNumber *) responseID {
    id responsed = nil;
    if([reply isKindOfClass:[NSMutableArray class]])
    {
        //NSLog(@"NSMutableArray");
        responsed = (NSMutableArray*)reply;
        if(responsed != NULL)
        {
            [listFamilyMember  removeAllObjects];
/*            [listFamilyMember release];
            listFamilyMember = nil;
            listFamilyMember = [[NSMutableArray alloc] initWithArray:responsed];
 */
            [listFamilyMember addObjectsFromArray:(NSArray*)responsed];
            [self.myTableView reloadData];
            self.navigationItem.leftBarButtonItem.enabled = NO;
            //self.title = workingDirectory;
        }
        [appDelegate hideProgress];
        NSLog(@"GetFolder Successfully Returned");
        
    }else if([reply isKindOfClass:[NSMutableDictionary class]]) {
        responsed = (NSMutableDictionary*)reply;
        //NSLog(@"NSMutableDictionary");
        if([responsed objectForKey:@"response"] != nil)
        {
            NSLog(@"SignOut Successfully Returned");
            NSString *respond = [responsed objectForKey:@"response"];
            if([respond isEqualToString:@"1"])
            {
                [self.navigationController popViewControllerAnimated:YES];
                [self dismissModalViewControllerAnimated:NO];
            }
            
        }else if([responsed objectForKey:@"Old Path"] != nil && [responsed objectForKey:@"Old Name"] != nil){
            NSLog(@"Renamed Successfully Returned");
            //rename {"Old Path":"\/4.png","Old Name":"4.png","New Path":"\/49.png","New Name":"49.png","Error":"","Code":"0"}
            //delete {"Path":"\/49.png","Error":"","Code":"0"}
            //upload <textarea>{"Path":"\/","Name":"2.jpg","Error":"","Code":0}</textarea>
            [newMan getFolder:workingDirectory];
        } else if([responsed objectForKey:@"Path"] != nil && [responsed objectForKey:@"Name"] != nil){
            NSLog(@"Upload Successfully Returned");
            [newMan getFolder:workingDirectory];
            
        } else if([responsed objectForKey:@"Path"] != nil && [responsed objectForKey:@"Code"] != nil){
            NSLog(@"Deleted Successfully Returned");

            //[listFamilyMember removeObjectAtIndex:selectedIndexPath.row];
            //[self.myTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:selectedIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            [newMan getFolder:workingDirectory];
        }else if([responsed objectForKey:@"Name"] != nil && [responsed objectForKey:@"Code"] != nil){
            NSLog(@"Add Folder Successfully Returned");
            [newMan getFolder:workingDirectory];
        }
        
    }else if([reply isKindOfClass:[NSString class]]) {
        //NSLog(@"Upload Return with = %@",(NSString*)reply);
//        ([responsed objectForKey:@"Path"] != nil && [responsed objectForKey:@"Name"] != nil){
        //NSLog(@"Upload Successfully Returned");
            
        [newMan getFolder:workingDirectory];
            
    }
    

    
   // //NSLog(@"RESPONSE object %@",reply);

  //  HelloWorldLayer *node = (HelloWorldLayer*)self.parent;  
}

- (IBAction)upToParentDirectory:(id)sender
{
    if(workingDirectory != NULL)
    {
       // //NSLog(@"Current Directoy accessed = %@",currentDirectoryPath);
        
        if(parentDirectory.count > 1)
        [parentDirectory removeObjectAtIndex:parentDirectory.count-1];
        NSString *newPath = [parentDirectory componentsJoinedByString:@"/"];
        
        //NSString* parentPath = [selectedObject objectForKey:@"Parent"];
        //NSString* onlyPath = [selectedObject objectForKey:@"Path"];
        
        [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
        [newMan getFolder:newPath];
        if(newPath.length < 1)
        {
            workingDirectory = [[NSString alloc] initWithString:@"/"];
        }else {
            workingDirectory = newPath;
        }
        
        NSLog(@"Working Directory onlyPath= %@",workingDirectory);
        NSLog(@"Parent Directory parentPath= %@",parentDirectory);

    }
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)info
{
     if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        //if iphone
       // //NSLog(@"it's iphone image gallery");
        [picker dismissModalViewControllerAnimated:YES];
    } else {
        [self.flipsidePopoverController3 dismissPopoverAnimated:YES];
    }
   // //NSLog(@"Image Size %f,%f",image.size.width,image.size.height);
    [appDelegate showProgressViewOnView:self.view withText:@"uploading file..." andType:0];
    
    //NSLog(@"upload at path = %@",workingDirectory)
    NSDate *date = [NSDate date];
    NSTimeInterval interval = [date timeIntervalSince1970];
    NSInteger unixTime = round(interval);
    
    NSString *uniqueFileName = [NSString stringWithFormat:@"image_%d.png",unixTime];
    
    [newMan uploadfile:uniqueFileName oldPath:workingDirectory ProgressBar:self.view Image:image];
}
///////////Adding Gestures on Image//////////////////
-(void)imagePickerControllerDidCancel: (UIImagePickerController *)picker {
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        //if iphone
       // //NSLog(@"it's iphone image gallery");
        [picker dismissModalViewControllerAnimated:YES];
    } else {
        [self.flipsidePopoverController3 dismissPopoverAnimated:YES];
    }
//    [self.flipsidePopoverController3 dismissPopoverAnimated:YES];
	//    [picker dismissModalViewControllerAnimated:YES];
}
/*
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)info
{
    [self.flipsidePopoverController3 dismissPopoverAnimated:YES];
	
    //	[picker dismissModalViewControllerAnimated:YES];
}*/

- (IBAction)uploadFile:(id)sender
{
    
    UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take Photo", @"Pick from library", nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleAutomatic;
    popupQuery.tag = kCameraActionSheet;
	[popupQuery showInView:self.view];
	[popupQuery release];
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex 
{	
    if(actionSheet.tag == kCameraActionSheet)
    {
        switch (buttonIndex) {
            case kCameraImport:
            {
                // //NSLog(@"take photo");
                [self GoToTakeAPhoto];
            }
                break;
                
            case kGalleryImport:
            {
                // //NSLog(@"upload from library");
                [self GoToImageGallery];
            }
                break;
            default:
            {
            }
                break;
        }
    }else if (actionSheet.tag == kMenuActionSheet)
    {
        switch (buttonIndex) {
            case kRename:
            {
                // //NSLog(@"take photo");
                [self actionRename];
            }
                break;
                
            case kDelete:
            {
                // //NSLog(@"upload from library");
                [self actionDelete];
            }
                break;
            case kProperties:
            {
                // //NSLog(@"upload from library");
                //[self getPr];
            }
                break;                
            default:
            {
            }
                break;
        }        
    }
}
-(void)GoToTakeAPhoto
{
	if ([UIImagePickerController
		 isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            //if iphone
            ////NSLog(@"it's iphone image gallery");
            [self presentModalViewController:imagePicker animated:YES];
        } else {
           // //NSLog(@"it's ipad image gallery");
            //else if ipad start
            if (!self.flipsidePopoverController3) {
                self.flipsidePopoverController3 = [[UIPopoverController alloc] initWithContentViewController:imagePicker];
               // [imagePicker release];
               // //NSLog(@"ipad PopView = 1");
            }
            
            if ([self.flipsidePopoverController3 isPopoverVisible]) {
                ////NSLog(@"ipad PopView = 2");
                [self.flipsidePopoverController3 dismissPopoverAnimated:YES];
            } else {
                ////NSLog(@" ipad PopView = 3");
                [self.flipsidePopoverController3 presentPopoverFromRect:CGRectMake(450-100-70, 908, 100, 100) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }        
            //ipad end
        }
	}
	else {
		UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Error accessing Camera" message:@"This device is unable to access camera"
													   delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}
-(void) GoToImageGallery{
	
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
	{
		imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
        imagePicker.mediaTypes =[UIImagePickerController availableMediaTypesForSourceType:imagePicker.sourceType];
		//	imagePicker.navigationBar.tintColor = [UIColor blackColor];
        /*
		[self presentModalViewController:imagePicker animated:YES];*/
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            //if iphone
           // //NSLog(@"it's iphone image gallery");
            [self presentModalViewController:imagePicker animated:YES];
        } else {
            //NSLog(@"it's ipad image gallery");
            //else if ipad start
            if (!self.flipsidePopoverController3) {
                self.flipsidePopoverController3 = [[UIPopoverController alloc] initWithContentViewController:imagePicker];
               // [imagePicker release];
              //  //NSLog(@"ipad PopView = 1");
            }
            
            if ([self.flipsidePopoverController3 isPopoverVisible]) {
               // //NSLog(@"ipad PopView = 2");
                [self.flipsidePopoverController3 dismissPopoverAnimated:YES];
            } else {
               // //NSLog(@" ipad PopView = 3");
                [self.flipsidePopoverController3 presentPopoverFromRect:CGRectMake(450-100-70, 908, 100, 100) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }        
            //ipad end
        }        
        
	}
	else {
		UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Error accessing Photo Library" message:@"This device does not support a Photo Library." delegate:nil cancelButtonTitle:@"OK"
											  otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}

- (IBAction)addFileorFolder:(id)sender
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Enter Folder Name " message:@"         " delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Save", nil];
    txtAddFile =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
    [txtAddFile setBackgroundColor:[UIColor whiteColor]];
    [txtAddFile setTag:kAddFolderAlertViewText];
    [alert setTag:kAddFolderAlertView];
    [alert addSubview:txtAddFile];
    [alert show];
    [alert release]; 
}
- (IBAction)renameFileorFolder:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Help Center" message:@"For any help please drop email at : muzammilpeer88@gmail.com " delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}
- (IBAction)moveTo:(id)sender
{
}
- (IBAction)logoutApp:(id)sender
{
}
- (IBAction)loginApp:(id)sender
{
}


#pragma mark - Table view data source


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return listFamilyMember.count;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return workingDirectory;
    }
    return @"";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle  reuseIdentifier:CellIdentifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
        /*
        UIColor *contentColor = ((indexPath.row % 2) == 0) ? [UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0]:  [UIColor colorWithRed:242.0/255 green:242.0/255 blue:242.0/255 alpha:0.0];
        UIColor *textFontColor = ((indexPath.row % 2) == 0) ? [UIColor colorWithRed:242.0/255 green:242.0/255 blue:242.0/255 alpha:1.0] :[UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0];
        
        cell.selectionStyle = ((indexPath.row % 2) == 0) ? UITableViewCellSelectionStyleGray: UITableViewCellSelectionStyleBlue;
         
        UIColor *contentColor = [UIColor colorWithRed:242.0/255 green:242.0/255 blue:242.0/255 alpha:0.0];
        UIColor *textFontColor = ((indexPath.row % 2) == 0) ? [UIColor colorWithRed:242.0/255 green:242.0/255 blue:242.0/255 alpha:1.0] :[UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0];
        
        cell.selectionStyle = ((indexPath.row % 2) == 0) ? UITableViewCellSelectionStyleGray: UITableViewCellSelectionStyleBlue;
        */
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.backgroundColor = [UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:0.5];
//        [cell.contentView setBackgroundColor:[UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:0.5]];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.detailTextLabel.textColor = [UIColor blackColor];

        [cell.textLabel setBackgroundColor:[UIColor clearColor]];
        //cell.detailTextLabel.font = [UIFont fontWithName:@"Helvetica" size:12];
//        cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:12.0];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        
        //        [cell.textLabel setBackgroundColor:color];
        
        
    }
    
    // Configure the cell...
    ////NSLog(@"count  = %@",[[response objectAtIndex:0] objectForKey:@"Path" ]);
    NSString *detailTxt = [NSString stringWithFormat:@"Date Created :%@",[[[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Properties"] objectForKey:@"DateCreated"] ];
    
    cell.detailTextLabel.text = detailTxt;
    
    cell.textLabel.text = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Filename"];
    bool isDir = false;
    
    NSString *filetype = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"File Type"];
    if([filetype isEqualToString:@"dir"])
    {
        isDir = true;
    }
    // if a download is deferred or in progress, return a placeholder image
    if(isDir)
    {
        cell.imageView.image = [UIImage imageNamed:@"_Close.png"];
    }else {
        cell.imageView.image = [UIImage imageNamed:@"_Documents.png"];
    }
    
    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == kRenameAlertView)
    {
        if (buttonIndex == 0)
        {
           // //NSLog(@"Button Index Zero ");
        }
        if (buttonIndex == 1)
        {
           // //NSLog(@"Button Index One");
            NSString * str = txtRename.text;
            if(str != NULL && str.length > 0)
            {
                if(listFamilyMember.count > 0)
                {
                    
                    NSString* OldPath = [[listFamilyMember objectAtIndex:currentRow] objectForKey:@"Path"];

                    NSString *filetype = [[listFamilyMember objectAtIndex:currentRow] objectForKey:@"File Type"];

                    if([filetype isEqualToString:@"dir"])
                    {
                        [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
                        ////NSLog(@"Folder Rename = %@ , OldPath = %@",str,OldPath);
                        [newMan renamed:str oldPath:OldPath];
                    }else {
                        [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
                        str = [str stringByAppendingFormat:@".%@",filetype];
                        //(@"File Rename = %@ , OldPath = %@",str,OldPath);
                        [newMan renamed:str oldPath:OldPath];
                    }
                }
            }
        }
    }else if(alertView.tag == kDeleteAlertView)
    {
        if (buttonIndex == 0)
        {
            //NSLog(@"Button Index Zero ");
        }
        if (buttonIndex == 1)
        {
            if(listFamilyMember.count > 0)
            {
                NSString* OldPath = [[listFamilyMember objectAtIndex:currentRow] objectForKey:@"Path"];

                //NSLog(@"Button Index One");
                //NSLog(@"Delete OldPath = %@",OldPath);
                [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
                [newMan deleted:OldPath];
            }
        }
        
    }else if(alertView.tag == kAddFolderAlertView)
    {
        if (buttonIndex == 0)
        {
            //NSLog(@"Button Index Zero ");
        }
        if (buttonIndex == 1)
        {
            /*
            NSString* OldPath = nil;
            if(listFamilyMember.count < 1)
            {
                OldPath = @"/";
                
            }else {
                 OldPath = [[listFamilyMember objectAtIndex:selectedIndexPath.row] objectForKey:@"Path"];
            }*/

            //NSLog(@"Button Index One");
            //NSLog(@"Delete OldPath = %@",OldPath);
            if(txtAddFile.text != NULL && txtAddFile.text.length > 0)
            {
                [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
                [newMan addFolder:txtAddFile.text Path:workingDirectory];
            }
        }
        
    }
}
- (void) actionRename
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Enter New Name " message:@"         " delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"Ok", nil];
    txtRename =[[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
    [txtRename setBackgroundColor:[UIColor whiteColor]];
    [txtRename setTag:kRenameAlertViewText];
    [alert setTag:kRenameAlertView];
    [alert addSubview:txtRename];
    [alert show];
    [alert release];
}
- (void) actionDelete
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Delete Confirmation!" message:@"Do you want to delete this record?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    [alert setTag:kDeleteAlertView];
    [alert show];
    [alert release];
}
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
     if (editingStyle == UITableViewCellEditingStyleDelete) {
     // Delete the row from the data source
         //selectedIndexPath = indexPath;
         currentRow = indexPath.row;
         [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
         [newMan deleted:[[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Path"]];
     }   
     else if (editingStyle == UITableViewCellEditingStyleInsert) {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }   
 }


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.navigationItem.leftBarButtonItem.enabled = NO;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.navigationItem.leftBarButtonItem.enabled = YES;
    //selectedIndexPath = indexPath;
    currentRow = indexPath.row;
}
#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    selectedObject = [listFamilyMember objectAtIndex:indexPath.row];
    bool isDir = false;
    NSString *filetype = [[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"File Type"];
    if([filetype isEqualToString:@"dir"])
    {
        isDir = true;
    }
    if(isDir)
    {
        //currentRow = indexPath.row;
        //NSLog(@"accessory Index= %d",currentRow);


        [workingDirectory release];
        workingDirectory = nil;
        
        [parentDirectory release];
        parentDirectory = nil;
        
        //currentDirectoryPath = [[NSString alloc] initWithString:(NSString*)[[listFamilyMember objectAtIndex:indexPath.row] objectForKey:@"Parent"]];
        ////NSLog(@"Current Path = %@",currentDirectoryPath);
        // if a download is deferred or in progress, return a placeholder image
        
        workingDirectory = [[NSString alloc] initWithString:[selectedObject objectForKey:@"Path"]];
        parentDirectory = [[NSMutableArray alloc] initWithArray:[(NSString*)[selectedObject objectForKey:@"Parent"] componentsSeparatedByString:@"/"]];
        
        //parentDirectory = [[NSString alloc] initWithString:[selectedObject objectForKey:@"Parent"]];
        
      //  NSLog(@"Acc Working Directory onlyPath= %@",workingDirectory);
      //  NSLog(@"Acc Parent Directory parentPath= %@",parentDirectory);
        
        [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
        [newMan getFolder:workingDirectory];
    }else {
        // Navigation logic may go here. Create and push another view controller.
        FileDetailViewController *detailViewController ;
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            detailViewController = [[FileDetailViewController alloc] initWithNibName:@"FileDetailViewController" bundle:nil];
        } else {
            detailViewController = [[FileDetailViewController alloc] initWithNibName:@"FileDetailViewController_iPad" bundle:nil];
        }
        // ...
        // Pass the selected object to the new view controller.
        detailViewController.myDelegate = (id)self;
        detailViewController.selectedObject = [listFamilyMember objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:detailViewController animated:YES];
        [detailViewController release];
    }

}
- (void) showActionMenu
{
    UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"" delegate:(id)self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Rename",@"Delete", nil];
    popupQuery.actionSheetStyle = UIActionSheetStyleAutomatic;
    popupQuery.tag = kMenuActionSheet;

    [popupQuery showInView:self.view];
    [popupQuery release];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [appDelegate hideProgress];
}
-(void)logout
{
    [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
    [newMan LogOut];

}
//File Detail View Delegate
-(void)loadFreshData 
{
    //NSLog(@"Delegate loadFreshData called ");
    [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
    [newMan getFolder:workingDirectory];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"LogOut" style:UIBarButtonItemStylePlain target:self action:@selector(logout) ] autorelease];
        
        self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(showActionMenu)] autorelease];
        
        self.navigationItem.leftBarButtonItem.enabled = NO;
        NSString * tparentDirectory = [[NSString alloc] initWithString:@"/"];
        parentDirectory = [[NSMutableArray alloc] initWithArray:[tparentDirectory componentsSeparatedByString:@"/"]];
        
        workingDirectory =  [[NSString alloc] initWithString:@"/"];
        [tparentDirectory release];
        tparentDirectory = nil;
        self.title = @"mbBox Cloud";
        newMan = [[Manager alloc] init];
        newMan.Delegate = (id)self;
        
        listFamilyMember = [[NSMutableArray alloc] init];
        _myTableView.backgroundColor = [UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0];
        
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
  //  [self.myTableView setSeparatorColor:[UIColor colorWithRed:41.0/255 green:152.0/255 blue:188.0/255 alpha:1.0]];        

    UIImageView * backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Wallpaper.png"]];
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
   	backgroundImage.frame = CGRectMake(0,0,screenWidth,screenHeight);
    
    [self.view addSubview:backgroundImage];
    [self.view sendSubviewToBack:backgroundImage];
    [backgroundImage release];
    
    
    appDelegate = (AppDelegate *) [UIApplication sharedApplication].delegate;
    
    
    imagePicker = [[UIImagePickerController alloc]init];
	imagePicker.delegate = (id)self;
    
    [appDelegate showProgressViewOnView:self.view withText:@"loading..." andType:0];
    [newMan getFolder:workingDirectory];
    
    

    // Do any additional setup after loading the view from its nib.
    /*    [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [listFamilyMember addObject:@"test"];
     [_tableViewMembers reloadData];
     */
}

- (void)viewDidUnload
{
    [self setMyTableView:nil];
    [super viewDidUnload];
    listFamilyMember = nil;
    imagePicker = nil;
    flipsidePopoverController3 = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}




- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

#pragma mark - Flipside View Controller
- (void)dealloc
{
    [_managedObjectContext release];
    [listFamilyMember release];
    [_myTableView release];
    [imagePicker release];
    [flipsidePopoverController3 release];

    [super dealloc];
}


@end
