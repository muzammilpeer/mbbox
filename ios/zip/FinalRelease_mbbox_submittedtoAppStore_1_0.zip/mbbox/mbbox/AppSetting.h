//
//  AppSetting.h
//  mbbox
//
//  Created by Muzammil Peer on 11/14/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#ifndef mbbox_AppSetting_h
#define mbbox_AppSetting_h

#define kAppKey @"6c3p9zesriioqi8"

#define kCameraActionSheet 1
#define kMenuActionSheet 2

//  For Camer Action Sheet  //
#define kGalleryImport 1
#define kCameraImport 0
//  For Menu Action Sheet  //
#define kRename 0
#define kDelete 1
#define kProperties 2
#define kDownload 2
#define kMove 3
#define kZip 4
#define kUnzip 5


#define kRenameAlertView 1111
#define kDeleteAlertView 1112
#define kUploadAlertView 1113
#define kAddFolderAlertView 1114


#define kRenameAlertViewText 2221
#define kAddFolderAlertViewText 2222

#endif
