//
//  Manager.h
//  magic_wall_initiatedSaad
//
//  Created by HuLeTS on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//



#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"


@protocol managerDelegate <NSObject>

-(void)response:(NSObject *)reply  ofid :(NSNumber *)responseID ;
@end


@interface Manager : NSObject
{
    NSString *URL;
    NSString *LoginURL;
    NSString *LogOutURL;
    NSString *SignUpURL;
   	ASIFormDataRequest *requestd;
    UIProgressView * uploadingBar;
}
@property (nonatomic,retain) id<managerDelegate> Delegate;
@property (retain, nonatomic) ASIFormDataRequest *requestd;


- (NSString*) getQueryString :(NSDictionary*) dict;
- (void) SignUp:(NSString*)email Password:(NSString*)password FirstName:(NSString*)firstname LastName:(NSString*)lastname NickName:(NSString*)nickname SecretKey:(NSString*)secretkey;
- (void) LogOut;
- (void) Login:(NSString*)email Password:(NSString*)password;
- (void) addFolder:(NSString*) folder Path:(NSString*)path;
- (void) getFolder:(NSString*) folder;
- (void) getFileInfo:(NSString*) path;
- (void) downloaded:(NSString*) path;
- (void) previewed:(NSString*) path;
- (void) deleted:(NSString*) path;
- (void) renamed:(NSString*)newname oldPath:(NSString*)oldpath;
- (void) uploadfile:(NSString*)filename oldPath:(NSString*)path ProgressBar:(UIView*)progressIndicator Image:(UIImage*) imageObject;

@end

