//
//  AppDelegate.h
//  mbbox
//
//  Created by Muzammil Peer on 11/11/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;
@class LoginViewController;
#import "MBProgressHUD.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, MBProgressHUDDelegate>
{
   MBProgressHUD * progressHud;
}

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@property (strong, nonatomic) MainViewController *mainViewController;
@property (strong, nonatomic) LoginViewController *loginViewController;

@property (nonatomic ,retain) MBProgressHUD * progressHud;
-(void) showProgressViewOnView:(UIView * ) view withText:(NSString *) text andType:(int) type;
-(void) hideProgress;
@end
