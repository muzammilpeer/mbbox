<?php

namespace Guzzle\Http\Exception;

use Guzzle\Common\Exception\RuntimeException;

class CouldNotRewindStreamException extends RuntimeException implements HttpException {}
