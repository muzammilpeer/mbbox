<?php
echo phpinfo();

?>