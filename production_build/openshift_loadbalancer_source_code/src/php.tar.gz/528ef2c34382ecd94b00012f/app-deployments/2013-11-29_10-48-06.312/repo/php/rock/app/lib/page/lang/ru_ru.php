<?php
/**
 * ru_ru的配置
 * 
 * @since 1.0
 * @package if
 * @subpackage plugin.pager.lang
 */
$message["pager_prev"] = "Пред";
$message["pager_next"] = "След";
$message["pager_first"] = "Первая";
$message["pager_last"] = "Последняя";
$message["pager_input_pageno"] = "Перейти:";
$message["pager_current_pageno"] = "Текущая: %d ";
$message["pager_total_page"] = "Всего: %d ";

?>
